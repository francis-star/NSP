﻿using System;

namespace 全国公司支撑系统_PC_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
