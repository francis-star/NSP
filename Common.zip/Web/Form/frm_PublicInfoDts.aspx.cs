﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;

namespace Web.Form
{
    public partial class frm_PublicInfoDts : System.Web.UI.Page
    {
        BLL_PublicInfoDts bLL_PublicInfoDts = new BLL_PublicInfoDts();

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}